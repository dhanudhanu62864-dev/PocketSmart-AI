# PocketSmart AI — Smart Budget & Recommendation Assistant

A runnable FastAPI + Jinja2 project based on the supplied PocketSmart AI project specification.

## Features
- User registration, login, logout and JWT-based API token
- Session information and recommendation history
- Home Interior Budget Planner
- Party Budget Planner
- Jewelry Budget Planner with optional outfit image upload
- Gemini integration when `GEMINI_API_KEY` is configured
- Safe mock recommendations when Gemini is unavailable
- Responsive HTML/CSS/JavaScript UI
- Platform-aware links for Amazon, Flipkart, IKEA, Swiggy, Zomato and OYO

## Run locally

1. Create a virtual environment:
   `python -m venv .venv`
2. Activate it.
3. Install dependencies:
   `pip install -r requirements.txt`
4. Copy `.env.example` to `.env` and set `SECRET_KEY`.
5. Optionally set `GEMINI_API_KEY` for AI-generated recommendations.
6. Start:
   `uvicorn app.main:app --reload`
7. Open http://127.0.0.1:8000

The demo works without a Gemini key by using deterministic fallback recommendations.

## API routes
- POST `/register`
- POST `/login`
- GET `/logout`
- POST `/token`
- GET `/session-info`
- GET `/session-data`
- POST `/generate-home`
- POST `/generate-party`
- POST `/generate-jewelry`
- GET `/history`
- GET `/recommendations-details`

## Note
Product prices and links in fallback mode are illustrative planning data, not live marketplace inventory.
