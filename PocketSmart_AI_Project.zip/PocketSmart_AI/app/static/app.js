function money(n){return new Intl.NumberFormat('en-IN',{style:'currency',currency:'INR',maximumFractionDigits:0}).format(Number(n||0))}
function renderResult(el,data){
 let html=`<div class="result"><b>${data.summary||'Recommendation plan'}</b>`;
 if(data.budget_allocation){html+=`<p><b>Budget allocation:</b> ${Object.entries(data.budget_allocation).map(([k,v])=>`${k}: ${money(v)}`).join(' · ')}</p>`}
 if(data.outfit_observation) html+=`<p>${data.outfit_observation}</p>`;
 (data.recommendations||[]).forEach(r=>{html+=`<div class="rec"><span><b>${r.name}</b><br><small>${r.category||''} · ${r.reason||''}</small></span><span>${money(r.estimated_price)}<br><a target="_blank" href="${r.url||'#'}">${r.platform||'View'}</a></span></div>`});
 if(data.mode==='fallback') html+=`<small class="muted">Demo fallback mode: prices are illustrative planning estimates.</small>`;
 html+='</div>'; el.innerHTML=html;
}
document.querySelectorAll('.planner').forEach(form=>{
 form.addEventListener('submit',async e=>{
  e.preventDefault();
  const btn=form.querySelector('button'); btn.disabled=true; btn.textContent='Generating…';
  try{
   const res=await fetch(form.dataset.endpoint,{method:'POST',body:new FormData(form)});
   const data=await res.json(); if(!res.ok) throw new Error(data.detail||'Request failed');
   const id=form.closest('.panel').id; renderResult(document.getElementById(id+'-result'),data);
  }catch(err){alert(err.message)}finally{btn.disabled=false;btn.textContent='Generate'}
 });
});