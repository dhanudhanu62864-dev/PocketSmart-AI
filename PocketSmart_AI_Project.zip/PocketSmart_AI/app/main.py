import base64, hashlib, hmac, os, secrets, sqlite3
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Optional

import jwt
from dotenv import load_dotenv
from fastapi import FastAPI, File, Form, Request, UploadFile, Depends, HTTPException
from fastapi.responses import HTMLResponse, RedirectResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from pydantic import BaseModel, Field

from .services.recommendations import home_recommendations, party_recommendations, jewelry_recommendations

load_dotenv()
BASE = Path(__file__).resolve().parent
DB = BASE / "pocketsmart.db"
SECRET = os.getenv("SECRET_KEY", "dev-secret-change-me")
ALGORITHM = "HS256"

app = FastAPI(title="PocketSmart AI", version="1.0.0")
app.mount("/static", StaticFiles(directory=BASE/"static"), name="static")
templates = Jinja2Templates(directory=str(BASE/"templates"))

def db():
    conn = sqlite3.connect(DB)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    conn = db()
    conn.executescript("""
    CREATE TABLE IF NOT EXISTS users(
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      username TEXT UNIQUE NOT NULL,
      password_hash TEXT NOT NULL,
      created_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS history(
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER NOT NULL,
      planner TEXT NOT NULL,
      input_json TEXT NOT NULL,
      result_json TEXT NOT NULL,
      created_at TEXT NOT NULL
    );
    """)
    conn.commit(); conn.close()

init_db()

def hash_password(password: str) -> str:
    salt = secrets.token_hex(16)
    digest = hashlib.pbkdf2_hmac("sha256", password.encode(), salt.encode(), 120_000)
    return f"{salt}${digest.hex()}"

def verify_password(password: str, stored: str) -> bool:
    try:
        salt, expected = stored.split("$", 1)
        got = hashlib.pbkdf2_hmac("sha256", password.encode(), salt.encode(), 120_000).hex()
        return hmac.compare_digest(got, expected)
    except Exception:
        return False

def token_for(user_id: int, username: str):
    return jwt.encode({"sub": str(user_id), "username": username, "exp": datetime.now(timezone.utc)+timedelta(hours=8)}, SECRET, algorithm=ALGORITHM)

def current_user(request: Request):
    token = request.cookies.get("access_token")
    if not token: return None
    try:
        payload = jwt.decode(token, SECRET, algorithms=[ALGORITHM])
        return {"id": int(payload["sub"]), "username": payload["username"]}
    except Exception:
        return None

def save_history(user_id, planner, inputs, result):
    conn=db()
    conn.execute("INSERT INTO history(user_id,planner,input_json,result_json,created_at) VALUES(?,?,?,?,?)",
                 (user_id, planner, __import__("json").dumps(inputs), __import__("json").dumps(result),
                  datetime.now(timezone.utc).isoformat()))
    conn.commit(); conn.close()

@app.get("/", response_class=HTMLResponse)
def home(request: Request):
    return templates.TemplateResponse("index.html", {"request":request, "user":current_user(request)})

@app.get("/register", response_class=HTMLResponse)
def register_page(request: Request):
    return templates.TemplateResponse("register.html", {"request":request, "user":current_user(request), "error":None})

@app.post("/register")
def register(username: str=Form(...), password: str=Form(...)):
    username=username.strip()
    if len(username)<3 or len(password)<6:
        return RedirectResponse("/register?error=Use+a+username+of+3%2B+chars+and+a+password+of+6%2B+chars", status_code=303)
    conn=db()
    try:
        cur=conn.execute("INSERT INTO users(username,password_hash,created_at) VALUES(?,?,?)",
                         (username,hash_password(password),datetime.now(timezone.utc).isoformat()))
        uid=cur.lastrowid; conn.commit()
    except sqlite3.IntegrityError:
        conn.close()
        return RedirectResponse("/register?error=Username+already+exists", status_code=303)
    conn.close()
    resp=RedirectResponse("/",status_code=303); resp.set_cookie("access_token",token_for(uid,username),httponly=True,samesite="lax"); return resp

@app.get("/login", response_class=HTMLResponse)
def login_page(request: Request):
    return templates.TemplateResponse("login.html", {"request":request, "user":current_user(request), "error":None})

@app.post("/login")
def login(username: str=Form(...), password: str=Form(...)):
    conn=db(); row=conn.execute("SELECT * FROM users WHERE username=?",(username.strip(),)).fetchone(); conn.close()
    if not row or not verify_password(password,row["password_hash"]):
        return RedirectResponse("/login?error=Invalid+username+or+password",status_code=303)
    resp=RedirectResponse("/",status_code=303); resp.set_cookie("access_token",token_for(row["id"],row["username"]),httponly=True,samesite="lax"); return resp

@app.get("/logout")
def logout():
    resp=RedirectResponse("/",status_code=303); resp.delete_cookie("access_token"); return resp

@app.post("/token")
def token(username: str=Form(...), password: str=Form(...)):
    conn=db(); row=conn.execute("SELECT * FROM users WHERE username=?",(username.strip(),)).fetchone(); conn.close()
    if not row or not verify_password(password,row["password_hash"]): raise HTTPException(401,"Invalid credentials")
    return {"access_token":token_for(row["id"],row["username"]),"token_type":"bearer"}

@app.get("/session-info")
def session_info(request: Request):
    user=current_user(request); return {"logged_in":bool(user),"user":user}

@app.get("/session-data")
def session_data(request: Request):
    user=current_user(request)
    if not user: raise HTTPException(401,"Login required")
    conn=db(); rows=conn.execute("SELECT id,planner,created_at FROM history WHERE user_id=? ORDER BY id DESC LIMIT 10",(user["id"],)).fetchall(); conn.close()
    return {"user":user,"recent": [dict(r) for r in rows]}

@app.post("/generate-home")
def generate_home(request: Request, budget: float=Form(...), rooms: str=Form("Living Room"), style: str=Form("Modern")):
    data={"budget":budget,"rooms":rooms,"style":style}; result=home_recommendations(data)
    user=current_user(request)
    if user: save_history(user["id"],"Home",data,result)
    return JSONResponse(result)

@app.post("/generate-party")
def generate_party(request: Request, budget: float=Form(...), guests: int=Form(...), event_type: str=Form("Birthday"), venue: str=Form("Home")):
    data={"budget":budget,"guests":guests,"event_type":event_type,"venue":venue}; result=party_recommendations(data)
    user=current_user(request)
    if user: save_history(user["id"],"Party",data,result)
    return JSONResponse(result)

@app.post("/generate-jewelry")
async def generate_jewelry(request: Request, budget: float=Form(...), occasion: str=Form("Special Occasion"), style: str=Form("Elegant"), outfit_image: Optional[UploadFile]=File(None)):
    image_bytes=None; mime="image/jpeg"
    if outfit_image and outfit_image.filename:
        image_bytes=await outfit_image.read()
        mime=outfit_image.content_type or mime
        if len(image_bytes)>5_000_000: raise HTTPException(413,"Image is too large")
    data={"budget":budget,"occasion":occasion,"style":style}; result=jewelry_recommendations(data,image_bytes,mime)
    user=current_user(request)
    if user: save_history(user["id"],"Jewelry",data,result)
    return JSONResponse(result)

@app.get("/history")
def history(request: Request):
    user=current_user(request)
    if not user: return RedirectResponse("/login",303)
    conn=db(); rows=conn.execute("SELECT * FROM history WHERE user_id=? ORDER BY id DESC",(user["id"],)).fetchall(); conn.close()
    import json
    records=[{"id":r["id"],"planner":r["planner"],"created_at":r["created_at"],"input":json.loads(r["input_json"]),"result":json.loads(r["result_json"])} for r in rows]
    return templates.TemplateResponse("history.html",{"request":request,"user":user,"records":records})

@app.get("/recommendations-details")
def recommendation_details(request: Request, history_id: int):
    user=current_user(request)
    if not user: raise HTTPException(401,"Login required")
    conn=db(); row=conn.execute("SELECT * FROM history WHERE id=? AND user_id=?",(history_id,user["id"])).fetchone(); conn.close()
    if not row: raise HTTPException(404,"Recommendation not found")
    import json
    return {"planner":row["planner"],"input":json.loads(row["input_json"]),"result":json.loads(row["result_json"])}

@app.get("/dashboard", response_class=HTMLResponse)
def dashboard(request: Request):
    return templates.TemplateResponse("dashboard.html",{"request":request,"user":current_user(request)})
