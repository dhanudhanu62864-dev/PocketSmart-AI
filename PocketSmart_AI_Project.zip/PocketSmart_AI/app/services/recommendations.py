import json, os
from typing import Any, Dict, List
from dotenv import load_dotenv

load_dotenv()

try:
    from google import genai
except Exception:
    genai = None

GEMINI_API_KEY = os.getenv("GEMINI_API_KEY", "")
GEMINI_MODEL = os.getenv("GEMINI_MODEL", "gemini-1.5-flash")

PLATFORM_URLS = {
    "Amazon": "https://www.amazon.in/",
    "Flipkart": "https://www.flipkart.com/",
    "IKEA": "https://www.ikea.com/in/en/",
    "Swiggy": "https://www.swiggy.com/",
    "Zomato": "https://www.zomato.com/",
    "OYO": "https://www.oyorooms.com/",
}

def _extract_json(text: str) -> Any:
    text = text.strip()
    if text.startswith("```"):
        text = text.strip("`")
        if text.startswith("json"):
            text = text[4:]
    try:
        return json.loads(text)
    except Exception:
        return None

def _gemini(prompt: str, image_bytes: bytes | None = None, mime_type: str = "image/jpeg") -> Any:
    if not GEMINI_API_KEY or genai is None:
        return None
    try:
        client = genai.Client(api_key=GEMINI_API_KEY)
        contents = [prompt]
        if image_bytes:
            contents.append({"mime_type": mime_type, "data": image_bytes})
        response = client.models.generate_content(model=GEMINI_MODEL, contents=contents)
        return _extract_json(response.text or "")
    except Exception:
        return None

def _within_budget(items: List[Dict[str, Any]], budget: float) -> List[Dict[str, Any]]:
    chosen, total = [], 0.0
    for item in items:
        price = float(item.get("price", 0))
        if total + price <= budget:
            chosen.append(item)
            total += price
    return chosen

def home_recommendations(data: Dict[str, Any]) -> Dict[str, Any]:
    budget = float(data.get("budget", 0))
    style = data.get("style", "Modern")
    rooms = data.get("rooms", "Living Room")
    prompt = f"""You are PocketSmart AI. Create budget-aware home interior recommendations.
Budget: {budget}. Rooms: {rooms}. Style: {style}.
Return JSON only with keys: summary, budget_allocation, recommendations.
Each recommendation must have name, category, estimated_price, platform, reason."""
    ai = _gemini(prompt)
    if ai:
        return ai

    catalog = [
        {"name":"LED Ceiling Light","category":"Lighting","price":799,"platform":"Amazon","reason":f"{style} look with low power use."},
        {"name":"Ceiling Fan","category":"Utility","price":2199,"platform":"Amazon","reason":"Practical room upgrade within a moderate budget."},
        {"name":"Side Table","category":"Furniture","price":2499,"platform":"IKEA","reason":"Compact furniture for living spaces."},
        {"name":"Wall Art Set","category":"Decor","price":1299,"platform":"Flipkart","reason":"Adds visual character without a large spend."},
        {"name":"Cushion Cover Set","category":"Decor","price":699,"platform":"Amazon","reason":"Easy way to coordinate the room style."},
        {"name":"Dining Table","category":"Furniture","price":7499,"platform":"IKEA","reason":"Functional option when dining furniture is required."},
    ]
    items = _within_budget(catalog, budget)
    total = sum(x["price"] for x in items)
    return {
        "summary": f"Illustrative {style} home plan for {rooms}, keeping the selected budget in mind.",
        "budget_allocation": {"furniture": round(total*.45,2), "lighting": round(total*.2,2), "decor": round(total*.35,2)},
        "recommendations": [{**x, "estimated_price": x.pop("price"), "url": PLATFORM_URLS[x["platform"]]} for x in items],
        "total_estimate": total,
        "mode": "fallback"
    }

def party_recommendations(data: Dict[str, Any]) -> Dict[str, Any]:
    budget = float(data.get("budget", 0))
    guests = int(data.get("guests", 1))
    event = data.get("event_type", "Birthday")
    venue = data.get("venue", "Home")
    prompt = f"""You are PocketSmart AI. Plan a {event} for {guests} guests at {venue}.
Budget: {budget}. Return JSON only with keys summary, budget_allocation, recommendations.
Cover catering, decoration, entertainment and optional accommodation."""
    ai = _gemini(prompt)
    if ai:
        return ai

    allocations = {
        "catering": round(budget*.50,2),
        "decoration": round(budget*.20,2),
        "entertainment": round(budget*.15,2),
        "contingency": round(budget*.15,2),
    }
    per_guest = allocations["catering"]/max(guests,1)
    recs = [
        {"name":f"Catering plan for {guests} guests","category":"Catering","estimated_price":allocations["catering"],"platform":"Zomato","reason":f"Planning allowance ≈ ₹{per_guest:.0f} per guest.","url":PLATFORM_URLS["Zomato"]},
        {"name":"Food delivery / bulk order options","category":"Catering","estimated_price":allocations["catering"],"platform":"Swiggy","reason":"Use the allocated catering amount to compare local options.","url":PLATFORM_URLS["Swiggy"]},
        {"name":"Decoration package","category":"Decoration","estimated_price":allocations["decoration"],"platform":"Amazon","reason":f"Suitable for a {event.lower()} theme.","url":PLATFORM_URLS["Amazon"]},
        {"name":"Entertainment allowance","category":"Entertainment","estimated_price":allocations["entertainment"],"platform":"Amazon","reason":"Reserve for games, speakers or small event accessories.","url":PLATFORM_URLS["Amazon"]},
        {"name":"Optional accommodation search","category":"Accommodation","estimated_price":0,"platform":"OYO","reason":"Useful when guests need nearby rooms.","url":PLATFORM_URLS["OYO"]},
    ]
    return {"summary":f"Illustrative {event} plan for {guests} guests at {venue}.", "budget_allocation":allocations, "recommendations":recs, "total_budget":budget, "mode":"fallback"}

def jewelry_recommendations(data: Dict[str, Any], image_bytes: bytes | None = None, mime_type: str = "image/jpeg") -> Dict[str, Any]:
    budget = float(data.get("budget", 0))
    occasion = data.get("occasion", "Special Occasion")
    style = data.get("style", "Elegant")
    prompt = f"""You are PocketSmart AI. Recommend jewelry for occasion={occasion}, style={style}, budget=₹{budget}.
If an outfit image is supplied, consider visible colors and aesthetics. Return JSON only with keys summary, outfit_observation, recommendations.
Each recommendation must have name, category, estimated_price, platform, reason."""
    ai = _gemini(prompt, image_bytes, mime_type) if image_bytes else _gemini(prompt)
    if ai:
        return ai

    catalog = [
        {"name":"Minimal Pendant Necklace","category":"Necklace","price":899,"platform":"Amazon","reason":f"Versatile {style.lower()} option for {occasion.lower()}."},
        {"name":"Statement Earrings","category":"Earrings","price":1299,"platform":"Flipkart","reason":"Adds a focal point while keeping the spend moderate."},
        {"name":"Classic Bracelet","category":"Bracelet","price":999,"platform":"Amazon","reason":"Easy to pair with coordinated outfits."},
        {"name":"Stone Stud Earrings","category":"Earrings","price":699,"platform":"Flipkart","reason":"Simple option for a polished look."},
    ]
    items = _within_budget(catalog, budget)
    return {
        "summary":f"Illustrative {style} jewelry plan for {occasion}.",
        "outfit_observation":"No reliable outfit-specific visual analysis was available in fallback mode." if not image_bytes else "Image supplied; fallback mode uses general style guidance rather than visual matching.",
        "recommendations":[{**x, "estimated_price":x.pop("price"), "url":PLATFORM_URLS[x["platform"]]} for x in items],
        "total_estimate":sum(x["estimated_price"] for x in [{**i, "estimated_price": i["price"]} for i in items]),
        "mode":"fallback"
    }
